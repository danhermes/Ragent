
from ragents.agents.base_agent import BaseAgent
from ragents.projects.yamlgen.modules.yaml_parser import YamlParser
from ragents.projects.yamlgen.modules.yaml_generator import YAMLGenerator

class PiperAgent(BaseAgent):
    def parse_input(self, input_path: str) -> dict:
        parser = YamlParser(input_path)
        structured_spec = parser.load()
        organized_spec = self.organize_fields(structured_spec)
        self.log(f"Parsed and organized input from {input_path}")
        return organized_spec

    def organize_fields(self, parsed_data: dict) -> dict:
        organized = {
            "workflow_name": parsed_data.get("Workflow Name"),
            "goal": parsed_data.get("Purpose / Goal"),
            "workflow_overview": parsed_data.get("Workflow Overview"),
            "inputs": parsed_data.get("Inputs", []),
            "outputs": parsed_data.get("Outputs", []),
            "apps_services_apis": parsed_data.get("Apps, Services, APIs", []),
            "core_nodes_logic": parsed_data.get("Core Nodes & Logic", []),
            "connections_transitions": parsed_data.get("Connections & Transitions", []),
            "test_scenarios": parsed_data.get("Test Scenarios", []),
            "authentication_permissions": parsed_data.get("Authentication & Permissions", []),
            "completion_checklist": parsed_data.get("Completion Checklist", []),
        }
        self.log("Organized fields into structured spec.")
        return organized

    def format_yaml(self, organized_spec: dict, tool: str) -> dict:
        generator = YAMLGenerator(organized_spec)
        method_name = f"generate_{tool}_yaml"
        if not hasattr(generator, method_name):
            raise ValueError(f"Unsupported tool: {tool}")
        generate_method = getattr(generator, method_name)
        yaml_output = generate_method()
        self.log(f"Formatted spec into {tool} YAML")
        return yaml_output

    def validate_yaml(self, yaml_content: dict, tool: str) -> bool:
        if not yaml_content:
            self.log("Validation failed: Empty YAML content.", level="error")
            return False
        self.log("Validation passed.")
        return True

    def save_yaml(self, yaml_content: dict, output_path: str):
        import yaml
        from pathlib import Path
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            yaml.dump(yaml_content, f, sort_keys=False)
        self.log(f"Saved YAML output to {output_path}")
