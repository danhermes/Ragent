
from ragents.agents.base_agent import BaseAgent
from ragents.agents.openai_connector import OpenAIConnector

class EliasAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.openai = OpenAIConnector()

    def enhance_spec(self, structured_spec: dict) -> dict:
        self.log("Enhancing spec via OpenAI.")
        prompt = self.build_enhancement_prompt(structured_spec)
        enhanced_response = self.openai.complete(prompt)
        enhanced_spec = self.parse_response(enhanced_response, structured_spec)
        self.log("Enhancement complete.")
        return enhanced_spec

    def build_enhancement_prompt(self, structured_spec: dict) -> str:
        prompt = (
            "You are a workflow designer expert.\n"
            "Enhance this automation spec by:\n"
            "- Proposing additional nodes if missing\n"
            "- Clarifying vague steps\n"
            "- Strengthening connections and logic\n\n"
            f"Here is the current structured spec:\n{structured_spec}\n\n"
            "Return the improved spec in JSON format."
        )
        return prompt

    def parse_response(self, gpt_response: str, original_spec: dict) -> dict:
        import json
        try:
            enhanced = json.loads(gpt_response)
            updated_spec = {**original_spec, **enhanced}
            self.log("Parsed and merged enhanced spec successfully.")
            return updated_spec
        except Exception as e:
            self.log(f"Failed to parse GPT response: {e}", level="error")
            return original_spec
