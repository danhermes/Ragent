
import argparse
import sys
from pathlib import Path
from ragents.projects.yamlgen.modules.yamlgen_dispatcher import YAMLgenDispatcher

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="YAMLgen CLI - Generate YAMLs from Automation Tech Specs")
    parser.add_argument("--input-file", required=True, help="Path to input .md file")
    parser.add_argument("--tool", required=True, choices=["autocoder", "n8n", "proof", "litlegos"], help="Target tool")
    parser.add_argument("--enhance", action="store_true", help="Enhance spec using Elias (OpenAI)")
    parser.add_argument("--output", help="Path to save generated YAML")
    parser.add_argument("--verbose", action="store_true", help="Verbose mode")
    return parser.parse_args()

def main():
    args = parse_args()
    dispatcher = YAMLgenDispatcher()
    try:
        dispatcher.generate_yaml(
            input_path=args.input_file,
            tool=args.tool,
            enhance=args.enhance,
            output_path=args.output,
            verbose=args.verbose
        )
        print(f"✅ YAML generation complete for tool: {args.tool}")
    except Exception as e:
        print(f"❌ Error: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
