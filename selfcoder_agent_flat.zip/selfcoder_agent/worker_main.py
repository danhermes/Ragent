from agent.worker_agent import WorkerAgent

if __name__ == "__main__":
    agent = WorkerAgent(name="Agent_Worker_001")
    task = (
        "Write a Python script that fetches current weather data for a list of cities "
        "using a public weather API and stores the results in a JSON file."
    )
    agent.run_task(task)
