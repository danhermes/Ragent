from agent.build_cycle import AgentBuildCycle
from utils.logger import log

def main():
    task = "Create a Python script that downloads the top 10 Reddit posts from /r/Python and saves them to a CSV file."
    cycle = AgentBuildCycle(agent_task=task, max_iterations=3)
    log("Starting build cycle...")
    cycle.run_cycle()
    log("Build cycle complete.")

if __name__ == "__main__":
    main()
