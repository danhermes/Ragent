from agent import code_writer, tester, runner_docker
from utils.logger import log

class AgentBuildCycle:
    def __init__(self, agent_task, max_iterations=3):
        self.agent_task = agent_task
        self.max_iterations = max_iterations

    def run_cycle(self):
        for i in range(self.max_iterations):
            log(f"--- Iteration {i+1} ---")
            file_path = code_writer.generate_agent(self.agent_task)
            stdout, stderr = runner_docker.run_code_in_docker(file_path)
            log(f"Execution Output:\n{stdout}\nErrors:\n{stderr}")
            test_file = tester.generate_tests(file_path)
            passed = tester.run_tests(test_file)
            if passed:
                log("✅ All tests passed!")
                break
            else:
                log("❌ Tests failed. Iterating...")
