from agent.build_cycle import AgentBuildCycle
from utils.logger import log

class WorkerAgent:
    def __init__(self, name):
        self.name = name

    def run_task(self, task_description):
        log(f"[{self.name}] Received task: {task_description}")
        cycle = AgentBuildCycle(agent_task=task_description, max_iterations=3)
        result = cycle.run_cycle()
        log(f"[{self.name}] Task completed.")
