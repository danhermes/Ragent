import openai
from utils.file_ops import save_code
import os

def generate_tests(code_path):
    with open(code_path, "r") as f:
        code = f.read()

    prompt = f"""
Given the following Python script, generate a test suite using pytest.
- Use the function `file_exists(path)` from `utils.cloud.dropbox_client`.
- Verify uploads.
- Clean up remote files using `delete_file(path)`.

Script:
{code}
"""

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
    )

    test_code = response.choices[0].message.content
    test_file_path = os.path.join("selfcoder_agent/tests", "test_generated.py")
    save_code(test_code, test_file_path)
    return test_file_path

def run_tests(test_file):
    import subprocess
    result = subprocess.run(["pytest", test_file], capture_output=True, text=True)
    return "failed" not in result.stdout.lower()
