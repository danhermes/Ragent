CODE_GEN_PROMPT = """
You are a Python coding assistant. Generate a script that performs the following task:

{task}

Make sure to include comments and avoid unnecessary complexity.
"""
