import subprocess
import os

def run_code_in_docker(file_path, image="agent_sandbox"):
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"Agent file not found: {file_path}")

    host_dir = os.path.abspath(os.path.dirname(file_path))
    container_path = "/sandbox/" + os.path.basename(file_path)

    result = subprocess.run([
        "docker", "run", "--rm",
        "-v", f"{host_dir}:/sandbox",
        image,
        "python", container_path
    ], capture_output=True, text=True)

    return result.stdout, result.stderr
