import openai
from utils.file_ops import save_code
from agent.prompts import CODE_GEN_PROMPT

def generate_agent(task_description):
    prompt = CODE_GEN_PROMPT.format(task=task_description)
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
    )
    code = response.choices[0].message.content
    file_path = save_code(code, "selfcoder_agent/generated_agents/agent_script.py")
    return file_path
